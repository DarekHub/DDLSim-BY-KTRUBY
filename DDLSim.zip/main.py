"""
DDLSim: Distributed Deep Learning Simulator (Prototype)

This script demonstrates a minimal example of distributed training
with simulated network conditions such as latency and packet loss.

Author: Kaitlyn Brishae Truby
Date: 2025-05-16
"""

import os
import time
import torch
import torch.distributed as dist
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel as DDP
import random

def setup(rank, world_size):
    os.environ['MASTER_ADDR'] = '127.0.0.1'
    os.environ['MASTER_PORT'] = '29500'
    dist.init_process_group("gloo", rank=rank, world_size=world_size)

def cleanup():
    dist.destroy_process_group()

class ToyModel(torch.nn.Module):
    def __init__(self):
        super(ToyModel, self).__init__()
        self.linear = torch.nn.Linear(10, 10)

    def forward(self, x):
        return self.linear(x)

def simulate_network_conditions():
    delay = random.uniform(0.01, 0.1)
    time.sleep(delay)
    if random.random() < 0.05:
        print("Packet lost simulated!")
        return False
    return True

def run_training(rank, world_size):
    print(f"Starting training on rank {rank}.")
    setup(rank, world_size)
    model = ToyModel()
    ddp_model = DDP(model)
    optimizer = torch.optim.SGD(ddp_model.parameters(), lr=0.001)
    loss_fn = torch.nn.MSELoss()

    for epoch in range(5):
        if not simulate_network_conditions():
            continue

        inputs = torch.randn(20, 10)
        labels = torch.randn(20, 10)
        optimizer.zero_grad()
        outputs = ddp_model(inputs)
        loss = loss_fn(outputs, labels)
        loss.backward()
        optimizer.step()

        if rank == 0:
            print(f"Epoch {epoch}, Loss: {loss.item():.4f}")

    cleanup()

if __name__ == "__main__":
    world_size = 2
    mp.spawn(run_training, args=(world_size,), nprocs=world_size, join=True)