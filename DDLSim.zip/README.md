# DDLSim – Distributed Deep Learning Simulator

**DDLSim** is an open-source simulation framework that enables researchers to prototype and test distributed deep learning workloads under variable network conditions.

## Features

- Multi-node distributed training using PyTorch Distributed & MPI4Py
- Simulated latency, packet loss, and fault conditions
- Modular plugin-ready design
- Metrics collection and visualization integration (Prometheus + Grafana)
- Ready for container orchestration (Kubernetes, Docker)

## Quick Start

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run the training simulation:
```bash
python main.py
```

## Vision

DDLSim aims to serve as a public academic platform for distributed AI infrastructure testing. Final deployment will include a live API, web dashboard, and open dataset sharing — hosted and credited through ilabt infrastructure.

## License

MIT License (with platform credit to ilabt.be)